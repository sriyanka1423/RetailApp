import pandas as pd
from sklearn.linear_model import LinearRegression
import joblib
import os

# Ensure model directory exists
os.makedirs("model", exist_ok=True)

# Load and clean data
households = pd.read_csv("data/400_households.csv")
transactions = pd.read_csv("data/400_transactions.csv")

# Clean column names
households.columns = households.columns.str.strip().str.lower()
transactions.columns = transactions.columns.str.strip().str.lower()

# Map loyalty_flag
households["loyalty_flag"] = households["l"].map({"y": 1, "n": 0}).fillna(0)

# Calculate total spend per household
total_spend = transactions.groupby("hshd_num")["spend"].sum().reset_index()
households = households.merge(total_spend, on="hshd_num", how="inner")

# Prepare features
X = households[["loyalty_flag", "hh_size", "children"]].fillna(0)
X = X.apply(pd.to_numeric, errors="coerce").fillna(0)
y = households["spend"].fillna(0)

# Train model
model = LinearRegression()
model.fit(X, y)

# Save model
joblib.dump(model, "model/clv_model.pkl")
print("✅ CLV model saved successfully.")
